const path = require("path"),
  fs = require("fs"),
  gulp = require("gulp"),
  realFavicon = require("gulp-real-favicon"),
  sass = require("gulp-sass"),
  plumber = require("gulp-plumber"),
  postcss = require("gulp-postcss"),
  uglify = require("gulp-uglify"),
  concat = require("gulp-concat"),
  rename = require("gulp-rename"),
  sourcemaps = require("gulp-sourcemaps"),
  autoprefixer = require("autoprefixer"),
  cssnano = require("cssnano"),
  svgSprite = require("gulp-svg-sprites");
watch = require("gulp-watch");

// File where the favicon markups are stored
const FAVICON_DATA_FILE = "faviconData.json",
  styles = "./src/scss";

gulp.task("sass", function () {
  var plugin = [autoprefixer(), cssnano()];
  return gulp
    .src(styles + "/styles.scss")
    .pipe(plumber())
    .pipe(sourcemaps.init())
    .pipe(sass())
    .pipe(postcss(plugin))
    .pipe(concat("styles.css"))
    .pipe(rename({ suffix: ".min" }))
    .pipe(sourcemaps.write("./"))
    .pipe(gulp.dest("./dist/css"));
});

gulp.task("favicon", function (done) {
  realFavicon.generateFavicon(
    {
      masterPicture: "./src/images/vectors/common/isolated-logo.svg",
      dest: "./dist/favicons",
      iconsPath: "/",
      design: {
        ios: {
          pictureAspect: "backgroundAndMargin",
          backgroundColor: "#ffffff",
          margin: "14%",
          assets: {
            ios6AndPriorIcons: true,
            ios7AndLaterIcons: true,
            precomposedIcons: true,
            declareOnlyDefaultIcon: true,
          },
        },
        desktopBrowser: {
          design: "raw",
        },
        windows: {
          pictureAspect: "noChange",
          backgroundColor: "#ffffff",
          onConflict: "override",
          assets: {
            windows80Ie10Tile: true,
            windows10Ie11EdgeTiles: {
              small: true,
              medium: true,
              big: true,
              rectangle: true,
            },
          },
        },
        androidChrome: {
          pictureAspect: "noChange",
          themeColor: "#ffffff",
          manifest: {
            display: "standalone",
            orientation: "notSet",
            onConflict: "override",
            declared: true,
          },
          assets: {
            legacyIcon: true,
            lowResolutionIcons: true,
          },
        },
        safariPinnedTab: {
          pictureAspect: "silhouette",
          themeColor: "#5bbad5",
        },
      },
      settings: {
        scalingAlgorithm: "Mitchell",
        errorOnImageTooSmall: false,
        readmeFile: false,
        htmlCodeFile: false,
        usePathAsIs: false,
      },
      markupFile: FAVICON_DATA_FILE,
    },
    function () {
      done();
    }
  );
});

gulp.task("inject-favicon-markups", function () {
  return gulp
    .src(["./index.html"])
    .pipe(
      realFavicon.injectFaviconMarkups(
        JSON.parse(fs.readFileSync(FAVICON_DATA_FILE)).favicon.html_code
      )
    )
    .pipe(gulp.dest("./templates"));
});

gulp.task("check-for-favicon-update", function (done) {
  var currentVersion = JSON.parse(fs.readFileSync(FAVICON_DATA_FILE)).version;
  realFavicon.checkForUpdates(currentVersion, function (err) {
    if (err) {
      throw err;
    }
  });
});

gulp.task("watch", function () {
  gulp.watch(styles + "/*.scss", gulp.series(["sass"]));
});
gulp.task("stream", function () {
  // Endless stream mode
  return watch("css/**/*.css", { ignoreInitial: false }).pipe(
    gulp.dest("build")
  );
});

gulp.task("callback", function () {
  // Callback mode, useful if any plugin in the pipeline depends on the `end`/`flush` event
  return watch("css/**/*.css", function () {
    gulp.src("css/**/*.css").pipe(gulp.dest("build"));
  });
});

gulp.task("default", gulp.series(["sass"]));
